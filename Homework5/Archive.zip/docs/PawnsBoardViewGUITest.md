![Screenshot20250324at65551PM.png](assets/PawnsBoardRedWin.png)

**RED WIN**

![Screenshot20250324at65632PM.png](assets/PawnsBoardTie.png)

**TIE**

![Screenshot20250324at63908PM.png](assets/PawnsBoard Card Placed.png)

**CARD PLACED**

![Screenshot20250324at63936PM.png](assets/PawnsBoard 2 Cards Placed.png)

**2 CARD PLACED**

![Screenshot20250324at65429PM.png](assets/PawnsBoardBlueWin.png)

**BLUE WIN**

![Screenshot20250324at63833PM.png](assets/PawnsBoardInitial 7x7.png)

**PAWN BOARD 7X7**

![Screenshot20250324at71340PM.png](assets/PawnsBoardGameState1.png)

**PAWN BOARD GAME STATE 1**

![Screenshot20250324at63620PM.png](assets/PawnsBoardsGameInitial 5x3.png)

**PAWN BOARD 5X3 INITIAL**

![Screenshot20250324at63710PM.png](assets/PawnsBoardGameInitial 5x3 Resized.png)

**PAWN BOARD 5X3 RESIZED**

![Screenshot20250324at63710PM.png](assets/Selected Cell.png)

**SELECTED CELL**

![Screenshot20250324at63710PM.png](assets/Post Confirmation.png)

**SELECTED CELL INELEGIBLE**

![Screenshot20250324at63710PM.png](assets/Sample Console Output.png)

**SAMPLE CONSOLE OUTPUT**

![Screenshot20250324at63710PM.png](assets/BLUE SELECT.png)

**BLUE SELECT**
